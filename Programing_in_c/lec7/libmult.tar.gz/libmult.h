#ifndef _LIBMULT_H_
#define _LIBMULT_H_

int triple(int x);
int quadruple(int x);
int quintuple(int x);
int sixtuple(int x);
int septuple(int x);

#endif /* _LIBMULT_H_ */
