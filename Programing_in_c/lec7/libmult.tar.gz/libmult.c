// 2023 Alfred Roos
#include <stdio.h>
#include <stdlib.h>
#include "libmult.h"

int triple(int x){
  return x *3;
}
int quadruple(int x){
  return x *4;
}
int quintuple(int x){
  return x *5;
}
int sixtuple(int x){
  return x *6;
}
int septuple(int x){
  return x *7;
}
