// 2023 Alfred Roos
#include <stdio.h>
#include <stdlib.h>
#include "maxmin.h"

int main(){
  int value;
  scanf("%d",&value);
  int arr[value];
  for(int i = 0; i < value; i++){
    scanf("%d",&arr[i]);
  }
  printf("maximum %d\nminimum %d\n",maximum(arr,value),minimum(arr,value));  return 0;
}
